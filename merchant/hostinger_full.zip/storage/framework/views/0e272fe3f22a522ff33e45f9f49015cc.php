

<?php $__env->startSection('title', 'Manage Districts - Ligen Dealer Locator'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2><i class="fas fa-map-marker-alt me-2"></i>Manage Districts</h2>
                    <p class="text-muted mb-0">Add and manage districts for dealer locations</p>
                </div>
                <div class="d-flex gap-2">
                    <a href="<?php echo e(route('admin.districts.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add New District
                    </a>
                    <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Back to Dashboard
                    </a>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Districts Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-list me-2"></i>All Districts</h5>
        </div>
        <div class="card-body">
            <?php if($districts->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>District Name</th>
                                <th>State</th>
                                <th>Status</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($district->name); ?></strong>
                                    </td>
                                    <td>
                                        <span class="badge bg-info"><?php echo e($district->state->name); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($district->is_active ? 'success' : 'secondary'); ?>">
                                            <?php echo e($district->is_active ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($district->created_at->format('M d, Y')); ?></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('admin.districts.edit', $district)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.districts.toggle-status', $district)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-<?php echo e($district->is_active ? 'warning' : 'success'); ?>" 
                                                        title="<?php echo e($district->is_active ? 'Deactivate' : 'Activate'); ?>">
                                                    <i class="fas fa-<?php echo e($district->is_active ? 'pause' : 'play'); ?>"></i>
                                                </button>
                                            </form>
                                            <form action="<?php echo e(route('admin.districts.destroy', $district)); ?>" method="POST" class="d-inline" 
                                                  onsubmit="return confirm('Are you sure you want to delete this district?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($districts->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-map-marker-alt text-muted mb-3" style="font-size: 3rem;"></i>
                    <h4 class="text-muted">No Districts Found</h4>
                    <p class="text-muted">No districts have been added yet.</p>
                    <a href="<?php echo e(route('admin.districts.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add First District
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\Ligen Dealer form\resources\views/admin/districts/index.blade.php ENDPATH**/ ?>