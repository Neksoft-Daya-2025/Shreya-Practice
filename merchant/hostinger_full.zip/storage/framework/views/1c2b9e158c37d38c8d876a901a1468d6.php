

<?php $__env->startSection('title', 'Search Results - Ligen Dealer Locator'); ?>

<?php $__env->startSection('content'); ?>
<div class="container my-5">
    <div class="row">
        <div class="col-lg-8">
            <div class="card search-results-card">
                <div class="card-header search-results-header">
                    <h3 class="mb-0">
                        <i class="fas fa-search me-2"></i>Search Results
                    </h3>
                    <p class="mb-0 mt-2 opacity-75">
                        <i class="fas fa-map-marker-alt me-1"></i>
                        <?php echo e($results->first()->state->name ?? 'Selected State'); ?>, <?php echo e($results->first()->district->name ?? 'Selected District'); ?>

                    </p>
                </div>
                <div class="card-body">
                    <?php if($results->count() > 0): ?>
                        <div class="row">
                            <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 mb-4">
                                    <div class="card dealer-card">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start mb-3">
                                                <h5 class="card-title"><?php echo e($dealer->business_name); ?></h5>
                                                <span class="badge badge-type"><?php echo e(ucfirst($dealer->type)); ?></span>
                                            </div>
                                            
                                            <div class="dealer-info">
                                                <i class="fas fa-user"></i>
                                                <strong>Contact:</strong> <?php echo e($dealer->contact_person); ?>

                                            </div>
                                            
                                            <div class="dealer-info">
                                                <i class="fas fa-phone"></i>
                                                <strong>Phone:</strong> <?php echo e($dealer->phone); ?>

                                                <?php if($dealer->alternate_phone): ?>
                                                    <br><small class="text-muted ms-4">Alt: <?php echo e($dealer->alternate_phone); ?></small>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <?php if($dealer->email): ?>
                                                <div class="dealer-info">
                                                    <i class="fas fa-envelope"></i>
                                                    <strong>Email:</strong> 
                                                    <a href="mailto:<?php echo e($dealer->email); ?>" class="text-decoration-none"><?php echo e($dealer->email); ?></a>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <div class="dealer-info">
                                                <i class="fas fa-map-marker-alt"></i>
                                                <strong>Address:</strong><br>
                                                <span class="ms-4"><?php echo e($dealer->address); ?><br>
                                                <?php echo e($dealer->city); ?><?php echo e($dealer->district ? ', ' . $dealer->district->name : ''); ?>, <?php echo e($dealer->state->name ?? $dealer->state); ?> - <?php echo e($dealer->pincode); ?></span>
                                            </div>
                                            
                                            <?php if($dealer->website): ?>
                                                <div class="dealer-info">
                                                    <i class="fas fa-globe"></i>
                                                    <strong>Website:</strong> 
                                                    <a href="<?php echo e($dealer->website); ?>" target="_blank" class="text-decoration-none text-primary">
                                                        Visit Website
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                            
                                            <?php if($dealer->business_description): ?>
                                                <div class="dealer-info">
                                                    <i class="fas fa-info-circle"></i>
                                                    <strong>Description:</strong><br>
                                                    <span class="ms-4 small text-muted"><?php echo e(Str::limit($dealer->business_description, 100)); ?></span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="no-results-section">
                            <i class="fas fa-search" style="font-size: 4rem;"></i>
                            <h4 class="text-muted mb-3">No Results Found</h4>
                            <p class="text-muted mb-4">
                                No dealers or distributors found in the selected state and district.
                            </p>
                            <a href="<?php echo e(route('search.index')); ?>" class="btn btn-primary">
                                <i class="fas fa-search me-2"></i>Search Again
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <div class="col-lg-4">
            <div class="card sidebar-card">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-search me-2"></i>Search Again</h5>
                </div>
                <div class="card-body">
                    <a href="<?php echo e(route('search.index')); ?>" class="btn btn-primary w-100">
                        <i class="fas fa-search me-2"></i>New Search
                    </a>
                </div>
            </div>
            
            <?php if($results->count() > 0): ?>
                <div class="card sidebar-card mt-3">
                    <div class="card-body">
                        <div class="results-summary">
                            <h6 class="mb-2">Search Summary</h6>
                            <p class="mb-1"><strong><?php echo e($results->count()); ?></strong> <?php echo e($results->count() == 1 ? 'result' : 'results'); ?> found</p>
                            <small class="text-muted">Dealer registration is managed by administrators only.</small>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\Ligen Dealer form\resources\views/search/results.blade.php ENDPATH**/ ?>