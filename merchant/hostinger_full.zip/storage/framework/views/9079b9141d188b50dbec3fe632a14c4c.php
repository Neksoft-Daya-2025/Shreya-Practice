

<?php $__env->startSection('title', 'Admin Dashboard - Ligen Dealer Locator'); ?>

<?php $__env->startSection('styles'); ?>
<style>
    /* Enhanced Button Styling */
    .btn-lg {
        padding: 0.75rem 1.5rem;
        font-size: 0.95rem;
        font-weight: 600;
        border-radius: 8px;
        transition: all 0.3s ease;
        text-transform: none;
        letter-spacing: 0.5px;
    }
    
    .btn-lg:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15) !important;
    }
    
    .btn-lg:active {
        transform: translateY(0);
    }
    
    /* Primary Button Enhancement */
    .btn-primary {
        background: linear-gradient(135deg, #6c757d, #495057);
        border: none;
        box-shadow: 0 2px 8px rgba(108, 117, 125, 0.3);
    }
    
    .btn-primary:hover {
        background: linear-gradient(135deg, #495057, #6c757d);
        box-shadow: 0 4px 15px rgba(108, 117, 125, 0.4);
    }
    
    /* Success Button Enhancement */
    .btn-success {
        background: linear-gradient(135deg, #82ac3a, #6b8a2e);
        border: none;
        box-shadow: 0 2px 8px rgba(130, 172, 58, 0.3);
    }
    
    .btn-success:hover {
        background: linear-gradient(135deg, #6b8a2e, #82ac3a);
        box-shadow: 0 4px 15px rgba(130, 172, 58, 0.4);
    }
    
    /* Outline Button Enhancements */
    .btn-outline-success {
        border: 2px solid #82ac3a;
        color: #82ac3a;
        background: rgba(130, 172, 58, 0.05);
    }
    
    .btn-outline-success:hover {
        background: linear-gradient(135deg, #82ac3a, #6b8a2e);
        border-color: #82ac3a;
        color: white;
        box-shadow: 0 4px 15px rgba(130, 172, 58, 0.3);
    }
    
    .btn-outline-primary {
        border: 2px solid #6c757d;
        color: #6c757d;
        background: rgba(108, 117, 125, 0.05);
    }
    
    .btn-outline-primary:hover {
        background: linear-gradient(135deg, #6c757d, #495057);
        border-color: #6c757d;
        color: white;
        box-shadow: 0 4px 15px rgba(108, 117, 125, 0.3);
    }
    
    .btn-outline-info {
        border: 2px solid #17a2b8;
        color: #17a2b8;
        background: rgba(23, 162, 184, 0.05);
    }
    
    .btn-outline-info:hover {
        background: linear-gradient(135deg, #17a2b8, #138496);
        border-color: #17a2b8;
        color: white;
        box-shadow: 0 4px 15px rgba(23, 162, 184, 0.3);
    }
    
    .btn-outline-danger {
        border: 2px solid #dc3545;
        color: #dc3545;
        background: rgba(220, 53, 69, 0.05);
    }
    
    .btn-outline-danger:hover {
        background: linear-gradient(135deg, #dc3545, #c82333);
        border-color: #dc3545;
        color: white;
        box-shadow: 0 4px 15px rgba(220, 53, 69, 0.3);
    }
    
    /* Icon Styling */
    .btn i {
        font-size: 0.9rem;
        margin-right: 0.5rem;
    }
    
    /* Responsive Button Layout */
    @media (max-width: 768px) {
        .d-flex.gap-3 {
            gap: 0.75rem !important;
        }
        
        .btn-lg {
            padding: 0.6rem 1.2rem;
            font-size: 0.85rem;
        }
    }
    
    @media (max-width: 576px) {
        .d-flex.gap-3 {
            flex-direction: column;
            gap: 0.5rem !important;
        }
        
        .btn-lg {
            width: 100%;
            justify-content: center;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('components.chatbot', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container my-5">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h2><i class="fas fa-tachometer-alt me-2"></i>Admin Dashboard</h2>
                    <p class="text-muted mb-0">Welcome, <?php echo e(Auth::guard('admin')->user()->name); ?></p>
                </div>
                <div class="d-flex gap-3 flex-wrap">
                    <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary btn-lg shadow-sm">
                        <i class="fas fa-plus me-2"></i>Add New Dealer
                    </a>
                    <a href="<?php echo e(route('admin.import')); ?>" class="btn btn-success btn-lg shadow-sm">
                        <i class="fas fa-file-import me-2"></i>Import CSV
                    </a>
                    <a href="<?php echo e(route('admin.export')); ?>" class="btn btn-outline-success btn-lg shadow-sm">
                        <i class="fas fa-download me-2"></i>Export CSV
                    </a>
                    <a href="<?php echo e(route('admin.states.index')); ?>" class="btn btn-outline-primary btn-lg shadow-sm">
                        <i class="fas fa-map me-2"></i>Manage States
                    </a>
                    <a href="<?php echo e(route('admin.districts.index')); ?>" class="btn btn-outline-info btn-lg shadow-sm">
                        <i class="fas fa-map-marker-alt me-2"></i>Manage Districts
                    </a>
                    <form action="<?php echo e(route('admin.logout')); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger btn-lg shadow-sm">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </button>
                    </form>
                </div>
            </div>

            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-users text-primary mb-2" style="font-size: 2rem;"></i>
                    <h4 class="card-title"><?php echo e($stats['total']); ?></h4>
                    <p class="card-text">Total Registrations</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-store text-success mb-2" style="font-size: 2rem;"></i>
                    <h4 class="card-title"><?php echo e($stats['dealers']); ?></h4>
                    <p class="card-text">Dealers</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-building text-info mb-2" style="font-size: 2rem;"></i>
                    <h4 class="card-title"><?php echo e($stats['distributors']); ?></h4>
                    <p class="card-text">Distributors</p>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 mb-3">
            <div class="card text-center">
                <div class="card-body">
                    <i class="fas fa-check-circle text-warning mb-2" style="font-size: 2rem;"></i>
                    <h4 class="card-title"><?php echo e($stats['active']); ?></h4>
                    <p class="card-text">Active</p>
                </div>
            </div>
        </div>
    </div>


    <!-- Dealers Table -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0"><i class="fas fa-list me-2"></i>All Dealers & Distributors</h5>
        </div>
        <div class="card-body">
            <?php if($dealers->count() > 0): ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Business Name</th>
                                <th>Contact Person</th>
                                <th>Type</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dealers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dealer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <strong><?php echo e($dealer->business_name); ?></strong>
                                        <?php if($dealer->website): ?>
                                            <br><small><a href="<?php echo e($dealer->website); ?>" target="_blank" class="text-decoration-none">
                                                <i class="fas fa-globe me-1"></i>Website
                                            </a></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($dealer->contact_person); ?></td>
                                    <td>
                                        <span class="badge bg-<?php echo e($dealer->type == 'dealer' ? 'success' : 'info'); ?>">
                                            <?php echo e(ucfirst($dealer->type)); ?>

                                        </span>
                                    </td>
                                    <td><?php echo e($dealer->email); ?></td>
                                    <td>
                                        <?php echo e($dealer->phone); ?>

                                        <?php if($dealer->alternate_phone): ?>
                                            <br><small class="text-muted">Alt: <?php echo e($dealer->alternate_phone); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php echo e($dealer->city); ?><?php echo e($dealer->district ? ', ' . $dealer->district->name : ''); ?><br>
                                        <small class="text-muted"><?php echo e($dealer->state->name ?? $dealer->state); ?> - <?php echo e($dealer->pincode); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-<?php echo e($dealer->status == 'active' ? 'success' : 'secondary'); ?>">
                                            <?php echo e(ucfirst($dealer->status)); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <a href="<?php echo e(route('admin.edit', $dealer)); ?>" class="btn btn-sm btn-outline-primary" title="Edit">
                                                <i class="fas fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('admin.toggle-status', $dealer)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PATCH'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-<?php echo e($dealer->status == 'active' ? 'warning' : 'success'); ?>" 
                                                        title="<?php echo e($dealer->status == 'active' ? 'Deactivate' : 'Activate'); ?>">
                                                    <i class="fas fa-<?php echo e($dealer->status == 'active' ? 'pause' : 'play'); ?>"></i>
                                                </button>
                                            </form>
                                            <form action="<?php echo e(route('admin.destroy', $dealer)); ?>" method="POST" class="d-inline" 
                                                  onsubmit="return confirm('Are you sure you want to delete this dealer/distributor?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($dealers->links()); ?>

                </div>
            <?php else: ?>
                <div class="text-center py-5">
                    <i class="fas fa-inbox text-muted mb-3" style="font-size: 3rem;"></i>
                    <h4 class="text-muted">No Dealers Found</h4>
                    <p class="text-muted">No dealers or distributors have been registered yet.</p>
                    <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Add First Dealer
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ASUS\Desktop\Ligen Dealer form\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>